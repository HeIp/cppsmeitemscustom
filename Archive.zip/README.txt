v2 folder contains where all the files should go
everything else is room swfs